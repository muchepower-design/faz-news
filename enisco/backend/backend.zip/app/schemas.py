from pydantic import BaseModel, EmailStr
from datetime import datetime, date
from typing import Optional, List
from uuid import UUID
from decimal import Decimal

# ==================== User schemas ====================
class UserBase(BaseModel):
    full_name: str
    email: EmailStr
    phone: Optional[str] = None

class UserCreate(UserBase):
    password: str

class UserResponse(UserBase):
    id: UUID
    user_type: str
    role: str
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str
    user: UserResponse


# ==================== Travel Request schemas ====================
class TravelRequestCreate(BaseModel):
    action_type: str          # quote, reservation, booking
    service_type: str
    full_name: str
    phone: str
    email: Optional[str] = None
    pickup_location: Optional[str] = None
    destination: Optional[str] = None
    travel_date: Optional[datetime] = None
    passengers: Optional[int] = None
    preferred_vehicle: Optional[str] = None
    base_amount: Optional[Decimal] = 0
    notes: Optional[str] = None

class TravelRequestResponse(TravelRequestCreate):
    id: UUID
    request_reference: str
    user_id: Optional[UUID]
    service_fee: Decimal
    total_amount: Decimal
    request_status: str
    payment_status: str
    created_at: datetime
    updated_at: datetime

class TravelRequestUpdate(BaseModel):
    request_status: Optional[str] = None
    payment_status: Optional[str] = None


# ==================== Insurance Request schemas ====================
class InsuranceRequestCreate(BaseModel):
    buyer_name: str
    phone: str
    email: Optional[str] = None
    vehicle_type: str
    vehicle_make_model: str
    number_plate: str
    insurance_type: str
    start_date: str            # accepts "YYYY-MM-DD"
    quarters: int
    base_premium: Optional[Decimal] = 0
    notes: Optional[str] = None

class InsuranceRequestResponse(BaseModel):
    id: UUID
    request_reference: str
    user_id: Optional[UUID]
    buyer_name: str
    phone: str
    email: Optional[str] = None
    vehicle_type: str
    vehicle_make_model: str
    number_plate: str
    insurance_type: str
    start_date: datetime       # returned as datetime (converted from string)
    quarters: int
    cover_days: int
    expiry_date: datetime
    base_premium: Decimal
    service_fee: Decimal
    total_amount: Decimal
    request_status: str
    payment_status: str
    notes: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


# ==================== Quotation schemas ====================
class QuotationCreate(BaseModel):
    request_type: str
    request_id: UUID
    quote_title: str
    quote_details: str
    base_amount: Decimal
    service_fee: Decimal
    total_amount: Decimal
    validity_date: Optional[date] = None

class QuotationResponse(QuotationCreate):
    id: UUID
    quotation_reference: str
    customer_name: str
    customer_phone: Optional[str]
    customer_email: Optional[EmailStr]
    status: str
    created_by: Optional[UUID]
    created_at: datetime


# ==================== Invoice schemas ====================
class InvoiceCreate(BaseModel):
    request_type: str
    request_id: UUID
    invoice_title: str
    invoice_details: str
    total_amount: Decimal
    due_date: Optional[date] = None

class InvoiceResponse(InvoiceCreate):
    id: UUID
    invoice_reference: str
    customer_name: str
    customer_phone: Optional[str]
    customer_email: Optional[EmailStr]
    amount_paid: Decimal
    balance: Decimal
    invoice_status: str
    created_by: Optional[UUID]
    created_at: datetime


# ==================== Payment schemas ====================
class PaymentInitiate(BaseModel):
    request_type: str
    request_id: UUID
    customer_name: str
    customer_phone: str
    amount: Decimal
    payment_method: str

class PaymentResponse(BaseModel):
    payment_reference: str
    gateway_reference: Optional[str]
    client_secret: Optional[str]
    status: str


# ==================== Visa Request schemas ====================
class VisaRequestCreate(BaseModel):
    applicant_name: str
    phone: str
    email: Optional[str] = None
    destination_country: str
    visa_type: str
    passport_number: str
    travel_date: Optional[datetime] = None
    base_fee: Optional[Decimal] = 0
    notes: Optional[str] = None

class VisaRequestResponse(VisaRequestCreate):
    id: UUID
    request_reference: str
    user_id: Optional[UUID]
    service_fee: Decimal
    total_amount: Decimal
    request_status: str
    payment_status: str
    created_at: datetime
    updated_at: Optional[datetime]

    class Config:
        from_attributes = True