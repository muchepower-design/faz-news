from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from ..database import get_db
from ..auth import get_current_user, require_role
from ..models import User, Quotation, TravelRequest, InsuranceRequest
from ..schemas import QuotationCreate, QuotationResponse
import uuid
from datetime import datetime

router = APIRouter(prefix="/api/quotations", tags=["quotations"])

@router.post("/", response_model=QuotationResponse)
def create_quotation(
    quote: QuotationCreate,
    current_user: User = Depends(require_role(["admin", "manager", "sales_officer"])),
    db: Session = Depends(get_db)
):
    # Fetch request to get customer details
    if quote.request_type == "travel":
        request_obj = db.query(TravelRequest).filter(TravelRequest.id == quote.request_id).first()
    else:
        request_obj = db.query(InsuranceRequest).filter(InsuranceRequest.id == quote.request_id).first()
    
    if not request_obj:
        raise HTTPException(status_code=404, detail="Request not found")
    
    quotation_ref = f"QTN-{datetime.now().strftime('%Y%m%d%H%M%S')}-{uuid.uuid4().hex[:6]}"
    
    db_quote = Quotation(
        quotation_reference=quotation_ref,
        request_type=quote.request_type,
        request_id=quote.request_id,
        user_id=request_obj.user_id,
        customer_name=request_obj.full_name if quote.request_type == "travel" else request_obj.buyer_name,
        customer_phone=request_obj.phone,
        customer_email=request_obj.email,
        quote_title=quote.quote_title,
        quote_details=quote.quote_details,
        base_amount=quote.base_amount,
        service_fee=quote.service_fee,
        total_amount=quote.total_amount,
        validity_date=quote.validity_date,
        created_by=current_user.id
    )
    db.add(db_quote)
    db.commit()
    db.refresh(db_quote)
    return db_quote

@router.get("/", response_model=List[QuotationResponse])
def list_quotations(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    if current_user.role in ["admin", "manager"]:
        return db.query(Quotation).all()
    else:
        return db.query(Quotation).filter(Quotation.user_id == current_user.id).all()