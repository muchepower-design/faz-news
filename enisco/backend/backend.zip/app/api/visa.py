from fastapi import APIRouter, Depends, BackgroundTasks
from sqlalchemy.orm import Session
from typing import List
from ..database import get_db
from ..auth import get_current_user, require_role
from ..models import User, VisaRequest, VisaFeeSetting
from ..schemas import VisaRequestCreate, VisaRequestResponse
from ..crud.visa import create_visa_request
from ..utils.payments import calculate_service_fee
#import uuid
from datetime import datetime
from uuid import UUID  # add with other imports

router = APIRouter(prefix="/api/visa", tags=["visa"])

@router.post("/request", response_model=VisaRequestResponse)
def create_visa_request_endpoint(
    request: VisaRequestCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Get service fee percentage from settings (default 10%)
    fee_setting = db.query(VisaFeeSetting).first()
    service_fee_percent = float(fee_setting.fee_value) if fee_setting else 10.0
    base_fee = request.base_fee or 0
    service_fee = calculate_service_fee(base_fee, service_fee_percent)
    total_amount = base_fee + service_fee

    visa_request = create_visa_request(
        db=db,
        user_id=current_user.id,
        request_reference=f"ENI-VISA-{datetime.now().strftime('%Y%m%d%H%M%S')}-{uuid.uuid4().hex[:3]}",
        applicant_name=request.applicant_name,
        phone=request.phone,
        email=request.email,
        destination_country=request.destination_country,
        visa_type=request.visa_type,
        passport_number=request.passport_number,
        travel_date=request.travel_date,
        base_fee=base_fee,
        service_fee=service_fee,
        total_amount=total_amount,
        notes=request.notes
    )
    return visa_request

@router.get("/requests", response_model=List[VisaRequestResponse])
def get_my_visa_requests(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
    skip: int = 0,
    limit: int = 100
):
    return db.query(VisaRequest).filter(VisaRequest.user_id == current_user.id).offset(skip).limit(limit).all()

@router.get("/admin/requests", response_model=List[VisaRequestResponse])
def get_all_visa_requests(
    current_user: User = Depends(require_role(["admin", "manager", "sales_officer"])),
    db: Session = Depends(get_db),
    skip: int = 0,
    limit: int = 100
):
    return db.query(VisaRequest).offset(skip).limit(limit).all()


@router.get("/request/{request_id}", response_model=VisaRequestResponse)
def get_visa_request(
    request_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        uuid_id = UUID(request_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid request ID")
    
    db_request = db.query(VisaRequest).filter(VisaRequest.id == uuid_id).first()
    if not db_request:
        raise HTTPException(status_code=404, detail="Request not found")
    
    if db_request.user_id != current_user.id and current_user.role not in ["admin", "manager", "sales_officer"]:
        raise HTTPException(status_code=403, detail="Access denied")
    
    return db_request