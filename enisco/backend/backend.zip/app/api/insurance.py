from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from datetime import datetime, timedelta
from decimal import Decimal
#import uuid
from ..database import get_db
from ..auth import get_current_user, require_role
from ..models import User, InsuranceRequest
from ..schemas import InsuranceRequestCreate, InsuranceRequestResponse
from ..crud.insurance import create_insurance_request
from uuid import UUID  # add with other imports

router = APIRouter(prefix="/api/insurance", tags=["insurance"])

def parse_date(date_str: str) -> datetime:
    """Convert YYYY-MM-DD string to datetime."""
    try:
        return datetime.strptime(date_str, "%Y-%m-%d")
    except ValueError:
        raise HTTPException(status_code=422, detail=f"Invalid start_date format: {date_str}. Use YYYY-MM-DD.")

@router.post("/request", response_model=InsuranceRequestResponse)
def create_insurance_request_endpoint(
    request: InsuranceRequestCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Convert empty strings to None
    if request.email == "":
        request.email = None
    if request.notes == "":
        request.notes = None

    # Parse start date
    start_date = parse_date(request.start_date)

    # Base premium as Decimal
    base_premium = request.base_premium if request.base_premium is not None else Decimal('500')
    service_fee_percent = Decimal('5.0')
    service_fee = (base_premium * service_fee_percent) / Decimal('100')
    total_amount = base_premium + service_fee

    quarter_days = 90
    cover_days = request.quarters * quarter_days
    expiry_date = start_date + timedelta(days=cover_days)

    insurance_request = create_insurance_request(
        db=db,
        user_id=current_user.id,
        request_reference=f"ENI-INS-{datetime.now().strftime('%Y%m%d%H%M%S')}-{uuid.uuid4().hex[:3]}",
        buyer_name=request.buyer_name,
        phone=request.phone,
        email=request.email,
        vehicle_type=request.vehicle_type,
        vehicle_make_model=request.vehicle_make_model,
        number_plate=request.number_plate,
        insurance_type=request.insurance_type,
        start_date=start_date,
        quarters=request.quarters,
        cover_days=cover_days,
        expiry_date=expiry_date,
        base_premium=base_premium,
        service_fee=service_fee,
        total_amount=total_amount,
        notes=request.notes
    )
    return insurance_request

@router.get("/requests", response_model=List[InsuranceRequestResponse])
def get_my_insurance_requests(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
    skip: int = 0,
    limit: int = 100
):
    return db.query(InsuranceRequest).filter(InsuranceRequest.user_id == current_user.id).offset(skip).limit(limit).all()

@router.get("/admin/requests", response_model=List[InsuranceRequestResponse])
def get_all_insurance_requests(
    current_user: User = Depends(require_role(["admin", "manager", "sales_officer"])),
    db: Session = Depends(get_db),
    skip: int = 0,
    limit: int = 100
):
    return db.query(InsuranceRequest).offset(skip).limit(limit).all()


@router.get("/request/{request_id}", response_model=InsuranceRequestResponse)
def get_insurance_request(
    request_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        uuid_id = UUID(request_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid request ID")
    
    db_request = db.query(InsuranceRequest).filter(InsuranceRequest.id == uuid_id).first()
    if not db_request:
        raise HTTPException(status_code=404, detail="Request not found")
    
    if db_request.user_id != current_user.id and current_user.role not in ["admin", "manager", "sales_officer"]:
        raise HTTPException(status_code=403, detail="Access denied")
    
    return db_request