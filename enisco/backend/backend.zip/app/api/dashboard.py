from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from datetime import date
from ..database import get_db
from ..auth import get_current_user
from ..models import User, TravelRequest, InsuranceRequest, Payment

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])

@router.get("/stats")
def get_stats(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    base_stats = {
        "travel_requests": db.query(TravelRequest).filter(TravelRequest.user_id == current_user.id).count(),
        "insurance_requests": db.query(InsuranceRequest).filter(InsuranceRequest.user_id == current_user.id).count(),
    }
    
    if current_user.role in ["admin", "manager"]:
        total_paid = db.query(Payment).filter(Payment.payment_status == "paid").all()
        revenue = sum(p.amount for p in total_paid)
        base_stats.update({
            "total_users": db.query(User).count(),
            "total_travel_requests": db.query(TravelRequest).count(),
            "total_insurance_requests": db.query(InsuranceRequest).count(),
            "revenue": float(revenue),
            "pending_requests": db.query(TravelRequest).filter(TravelRequest.request_status == "request_received").count() +
                                db.query(InsuranceRequest).filter(InsuranceRequest.request_status == "quote_generated").count(),
            "awaiting_payment": db.query(TravelRequest).filter(TravelRequest.payment_status == "pending").count() +
                                db.query(InsuranceRequest).filter(InsuranceRequest.payment_status == "pending").count(),
        })
    
    if current_user.role in ["sales_officer", "finance_officer", "operations_manager"]:
        today = date.today()
        base_stats.update({
            "pending_requests": db.query(TravelRequest).filter(TravelRequest.request_status == "request_received").count(),
            "awaiting_payment": db.query(TravelRequest).filter(TravelRequest.payment_status == "pending").count(),
            "today_transfers": db.query(TravelRequest).filter(
                TravelRequest.service_type == "airport_transfer",
                TravelRequest.travel_date == today
            ).count(),
        })
    
    return base_stats