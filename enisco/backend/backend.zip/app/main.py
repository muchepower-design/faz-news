from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .config import settings
from .database import engine, Base
from .api import auth, travel, insurance, payments, quotations, invoices, webhooks, dashboard, visa, users

# Create tables
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Enisco API", version="1.0.0")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth.router)
app.include_router(travel.router)
app.include_router(insurance.router)
app.include_router(payments.router)
app.include_router(quotations.router)
app.include_router(invoices.router)
app.include_router(webhooks.router)
app.include_router(dashboard.router)
app.include_router(visa.router)
app.include_router(users.router)

@app.get("/")
def root():
    return {"message": "Enisco API is running", "status": "active"}