# backend/app/models.py
from sqlalchemy import Column, String, DateTime, Boolean, Numeric, Integer, Enum, ForeignKey, JSON, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from .database import Base
import uuid

class User(Base):
    __tablename__ = "users"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    full_name = Column(String(150), nullable=False)
    email = Column(String(150), unique=True, nullable=False)
    phone = Column(String(50))
    password_hash = Column(String(255), nullable=False)
    user_type = Column(Enum('client', 'staff', 'manager', 'admin', name='user_type_enum'), nullable=False)
    role = Column(Enum('client', 'sales_officer', 'finance_officer', 'operations_manager', 'admin', name='role_enum'), default='client')
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    travel_requests = relationship("TravelRequest", back_populates="user")
    insurance_requests = relationship("InsuranceRequest", back_populates="user")
    quotations = relationship("Quotation", foreign_keys="Quotation.created_by")
    invoices = relationship("Invoice", foreign_keys="Invoice.created_by")
    payments = relationship("Payment", foreign_keys="Payment.user_id")
    activity_logs = relationship("ActivityLog", back_populates="user")
    visa_requests = relationship("VisaRequest", back_populates="user")

class ServiceFeeSetting(Base):
    __tablename__ = "service_fee_settings"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    service_type = Column(Enum('flight_ticketing', 'insurance', name='service_type_enum'), nullable=False)
    fee_type = Column(Enum('percentage', 'fixed', name='fee_type_enum'), default='percentage')
    fee_value = Column(Numeric(10,2), nullable=False)
    updated_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

class TravelRequest(Base):
    __tablename__ = "travel_requests"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    request_reference = Column(String(50), unique=True, nullable=False)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    action_type = Column(Enum('quote', 'reservation', 'booking', name='action_type_enum'), nullable=False)
    service_type = Column(Enum('airport_transfer', 'vehicle_rental', 'flight_ticketing', name='travel_service_type_enum'), nullable=False)
    full_name = Column(String(150), nullable=False)
    phone = Column(String(50), nullable=False)
    email = Column(String(150))
    pickup_location = Column(String(255))
    destination = Column(String(255))
    travel_date = Column(DateTime)
    travel_time = Column(DateTime)
    passengers = Column(Integer)
    preferred_vehicle = Column(String(100))
    base_amount = Column(Numeric(12,2), default=0)
    service_fee = Column(Numeric(12,2), default=0)
    total_amount = Column(Numeric(12,2), default=0)
    payment_method = Column(String(50))
    notes = Column(Text)
    request_status = Column(Enum('request_received', 'quotation_sent', 'reserved', 'awaiting_payment', 'confirmed_booking', 'completed', 'cancelled', name='travel_status_enum'), default='request_received')
    payment_status = Column(Enum('pending', 'paid', 'failed', 'not_required', name='payment_status_enum'), default='pending')
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    #updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    user = relationship("User", back_populates="travel_requests")

class InsuranceRequest(Base):
    __tablename__ = "insurance_requests"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    request_reference = Column(String(50), unique=True, nullable=False)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    buyer_name = Column(String(150), nullable=False)
    phone = Column(String(50), nullable=False)
    email = Column(String(150))
    vehicle_type = Column(String(100), nullable=False)
    vehicle_make_model = Column(String(150), nullable=False)
    number_plate = Column(String(50), nullable=False)
    insurance_type = Column(Enum('third_party', 'comprehensive', name='insurance_type_enum'), nullable=False)
    start_date = Column(DateTime, nullable=False)
    quarters = Column(Integer, nullable=False)
    cover_days = Column(Integer, nullable=False)
    expiry_date = Column(DateTime, nullable=False)
    base_premium = Column(Numeric(12,2), default=0)
    service_fee = Column(Numeric(12,2), default=0)
    total_amount = Column(Numeric(12,2), default=0)
    payment_method = Column(String(50))
    request_status = Column(Enum('quote_generated', 'awaiting_documents', 'awaiting_payment', 'active_cover', 'expired', 'renewed', 'cancelled', name='insurance_status_enum'), default='quote_generated')
    payment_status = Column(Enum('pending', 'paid', 'failed', name='insurance_payment_status_enum'), default='pending')
    notes = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    user = relationship("User", back_populates="insurance_requests")

class Quotation(Base):
    __tablename__ = "quotations"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    quotation_reference = Column(String(80), unique=True, nullable=False)
    request_type = Column(Enum('travel', 'insurance', name='request_type_enum'), nullable=False)
    request_id = Column(UUID(as_uuid=True), nullable=False)  # can be travel_request.id or insurance_request.id
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))  # client
    customer_name = Column(String(150), nullable=False)
    customer_phone = Column(String(50))
    customer_email = Column(String(150))
    quote_title = Column(String(200), nullable=False)
    quote_details = Column(Text, nullable=False)
    base_amount = Column(Numeric(12,2), default=0)
    service_fee = Column(Numeric(12,2), default=0)
    total_amount = Column(Numeric(12,2), default=0)
    validity_date = Column(DateTime)
    status = Column(Enum('draft', 'sent', 'accepted', 'rejected', 'expired', name='quote_status_enum'), default='draft')
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))  # staff who created
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class Invoice(Base):
    __tablename__ = "invoices"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    invoice_reference = Column(String(80), unique=True, nullable=False)
    request_type = Column(Enum('travel', 'insurance', name='request_type_enum'), nullable=False)
    request_id = Column(UUID(as_uuid=True), nullable=False)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    customer_name = Column(String(150), nullable=False)
    customer_phone = Column(String(50))
    customer_email = Column(String(150))
    invoice_title = Column(String(200), nullable=False)
    invoice_details = Column(Text, nullable=False)
    total_amount = Column(Numeric(12,2), nullable=False, default=0)
    amount_paid = Column(Numeric(12,2), default=0)
    balance = Column(Numeric(12,2), default=0)
    invoice_status = Column(Enum('unpaid', 'part_paid', 'paid', 'cancelled', name='invoice_status_enum'), default='unpaid')
    due_date = Column(DateTime)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    payments = relationship("Payment", back_populates="invoice")

class Payment(Base):
    __tablename__ = "payments"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    payment_reference = Column(String(80), unique=True, nullable=False)
    request_type = Column(Enum('travel', 'insurance', name='request_type_enum'), nullable=False)
    request_id = Column(UUID(as_uuid=True), nullable=False)
    invoice_id = Column(UUID(as_uuid=True), ForeignKey("invoices.id"), nullable=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    customer_name = Column(String(150), nullable=False)
    customer_phone = Column(String(50), nullable=False)
    amount = Column(Numeric(12,2), nullable=False)
    payment_method = Column(String(50), nullable=False)
    gateway_reference = Column(String(150))
    payment_status = Column(Enum('pending', 'paid', 'failed', 'cancelled', name='payment_status_enum'), default='pending')
    notes = Column(Text)
    webhook_data = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    invoice = relationship("Invoice", back_populates="payments")

class ActivityLog(Base):
    __tablename__ = "activity_logs"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    action_type = Column(String(100), nullable=False)
    description = Column(Text, nullable=False)
    ip_address = Column(String(45))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    user = relationship("User", back_populates="activity_logs")

class VisaRequest(Base):
    __tablename__ = "visa_requests"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    request_reference = Column(String(50), unique=True, nullable=False)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    applicant_name = Column(String(150), nullable=False)
    phone = Column(String(50), nullable=False)
    email = Column(String(150))
    destination_country = Column(String(100), nullable=False)
    visa_type = Column(Enum('tourist', 'business', 'student', 'transit', 'work', name='visa_type_enum'), nullable=False)
    passport_number = Column(String(50), nullable=False)
    travel_date = Column(DateTime)
    base_fee = Column(Numeric(12,2), default=0)
    service_fee = Column(Numeric(12,2), default=0)
    total_amount = Column(Numeric(12,2), default=0)
    payment_method = Column(String(50))
    request_status = Column(Enum('pending_review', 'documents_required', 'processing', 'approved', 'rejected', 'completed', 'cancelled', name='visa_status_enum'), default='pending_review')
    payment_status = Column(Enum('pending', 'paid', 'failed', name='visa_payment_status_enum'), default='pending')
    notes = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    user = relationship("User", back_populates="visa_requests")


class VisaFeeSetting(Base):
    __tablename__ = "visa_fee_settings"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    destination_country = Column(String(100), nullable=True)   # NULL means applies to all
    visa_type = Column(Enum('tourist', 'business', 'student', 'transit', 'work', name='visa_type_enum'), nullable=True)
    fee_type = Column(Enum('percentage', 'fixed', name='fee_type_enum'), default='percentage')
    fee_value = Column(Numeric(10,2), nullable=False)
    updated_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())