from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..database import get_db
from ..auth import get_current_user
from ..models import User, TravelRequest, InsuranceRequest, VisaRequest

router = APIRouter(prefix="/api/requests", tags=["requests"])

@router.get("/pending")
def get_pending_requests(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    # Allow all staff roles
    if current_user.role not in ['sales_officer', 'finance_officer', 'operations_manager', 'admin', 'manager']:
        return []  # or raise 403

    pending_travel = db.query(TravelRequest).filter(
        TravelRequest.request_status.in_(['request_received', 'quotation_sent', 'awaiting_payment'])
    ).all()
    pending_insurance = db.query(InsuranceRequest).filter(
        InsuranceRequest.request_status.in_(['quote_generated', 'awaiting_payment'])
    ).all()
    pending_visa = db.query(VisaRequest).filter(
        VisaRequest.request_status.in_(['pending_review', 'documents_required'])
    ).all()

    result = []
    for r in pending_travel:
        result.append({
            "id": str(r.id),
            "request_reference": r.request_reference,
            "full_name": r.full_name,
            "service_type": r.service_type,
            "request_status": r.request_status,
            "request_type": "travel",
            "created_at": r.created_at
        })
    for r in pending_insurance:
        result.append({
            "id": str(r.id),
            "request_reference": r.request_reference,
            "full_name": r.buyer_name,
            "service_type": "insurance",
            "request_status": r.request_status,
            "request_type": "insurance",
            "created_at": r.created_at
        })
    for r in pending_visa:
        result.append({
            "id": str(r.id),
            "request_reference": r.request_reference,
            "full_name": r.applicant_name,
            "service_type": "visa",
            "request_status": r.request_status,
            "request_type": "visa",
            "created_at": r.created_at
        })
    # Sort by creation date descending
    result.sort(key=lambda x: x['created_at'], reverse=True)
    return result